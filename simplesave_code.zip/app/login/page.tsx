"use client";

import { useActionState } from "react";
import { loginByEmail, quickLogin } from "./actions";

export default function LoginPage() {
  const [error, formAction, pending] = useActionState(loginByEmail, undefined);

  return (
    <main className="flex flex-1 items-center justify-center px-6 py-16">
      <div className="card anim-fade w-full max-w-md rounded-3xl p-8">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary-2 to-primary-deep shadow-[0_6px_16px_-4px_rgba(37,73,201,0.5)]">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M4 13.5 12 6l8 7.5" stroke="#fff" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <div>
            <div className="display text-xl font-extrabold">SimpleSave</div>
            <div className="text-[11px] font-medium text-ink-3">פשוט לחסוך</div>
          </div>
        </div>
        <h1 className="display mb-1 mt-6 text-3xl font-bold">כניסה</h1>
        <p className="mb-6 text-sm text-ink-2">התחברו כדי לראות את הבקשות והאזור האישי שלכם.</p>

        <form action={formAction} className="space-y-4">
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-semibold text-ink-2">אימייל</span>
            <input
              name="email"
              type="email"
              required
              dir="ltr"
              placeholder="you@simplesave.co.il"
              className="w-full rounded-xl border border-rule-strong bg-paper px-4 py-3 text-left outline-none focus:border-primary"
            />
          </label>
          {error && <p className="text-sm text-risk-high">{error}</p>}
          <button type="submit" disabled={pending} className="btn-primary press w-full py-3 disabled:opacity-50">
            {pending ? "מתחבר…" : "כניסה"}
          </button>
        </form>

        <div className="mt-8 border-t border-rule pt-6">
          <p className="lbl mb-3">כניסה מהירה (הדגמה)</p>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => quickLogin("client")} className="btn-ghost press flex-1 px-3 py-2.5 text-sm">לקוח · יוסי</button>
            <button onClick={() => quickLogin("advisor")} className="btn-ghost press flex-1 px-3 py-2.5 text-sm">יועץ · דן</button>
            <button onClick={() => quickLogin("admin")} className="btn-ghost press flex-1 px-3 py-2.5 text-sm">מנהל</button>
          </div>
        </div>
      </div>
    </main>
  );
}
